import os




def cls():
    os.system('cls')  # Clears the screen
    
